# Disbot

A new, simple discord self-made using python.

100% Open Source code 👌

For fun purposes only.

## TODO (General)

All the following commands are completed or incomplete.

- [X] Roll commands
- [X] About the Bot
- [X] Reformat the code.
- [X] New About the server (**PC**)

## TODO (Joke Commands)

- [X] Ban commands
- [X] Kick Commands
> Both Commands will send a rickroll to Y O U
